using UdonSharp;
using UnityEngine;
using UnityEngine.UI;
using VRC.SDKBase;
using VRC.Udon;

namespace SaccFlightAndVehicles
{
    [DefaultExecutionOrder(5)]
    [UdonBehaviourSyncMode(BehaviourSyncMode.Manual)]
    public class DFUNC_Bomb : UdonSharpBehaviour
    {
        [SerializeField] public UdonSharpBehaviour SAVControl;
        public Animator BombAnimator;
        public GameObject Bomb;
        [Tooltip("How long it takes to fully reload from empty in seconds. Can be inaccurate because it can only reload by integers per resupply")]
        public float FullReloadTimeSec = 8;
        public Text HUDText_Bomb_ammo;
        public int NumBomb = 4;
        [Tooltip("Delay between bomb drops when holding the trigger")]
        public float BombHoldDelay = 0.5f;
        [Tooltip("Minimum delay between bomb drops")]
        public float BombDelay = 0f;
        [Tooltip("Points at which bombs appear, each succesive bomb appears at the next transform")]
        public Transform[] BombLaunchPoints;
        [Tooltip("Allow user to fire the weapon while the vehicle is on the ground taxiing?")]
        public bool AllowFiringWhenGrounded = false;
        public bool DoAnimBool = false;
        [Tooltip("Animator bool that is true when this function is selected")]
        public string AnimBoolName = "BombSelected";
        [Tooltip("Animator float that represents how many bombs are left")]
        public string AnimFloatName = "bombs";
        [Tooltip("Animator trigger that is set when a bomb is dropped")]
        public string AnimFiredTriggerName = "bomblaunched";
        [Tooltip("Should the boolean stay true if the pilot exits with it selected?")]
        public bool AnimBoolStayTrueOnExit;
        [Tooltip("Dropped bombs will be parented to this object, use if you happen to have some kind of moving origin system")]
        public Transform WorldParent;
        public Camera AtGCam;
        public GameObject AtGScreen;

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        [Header("///////////////////// <KitKat CCIP> ///////////////////////")]
        [Tooltip("Predict where bomb will land?")]
        [SerializeField] private bool DoCCIP = false;
        [SerializeField] private SAV_HUDController LinkedHUDControl;
        [SerializeField] private Transform LinkedHudVelocityVector;
        [SerializeField] private Transform HudCCIP;
        [SerializeField] private float CCIPSmoothing = 0.5f;
        [SerializeField] private Transform TopOfCCIPLine;
        [SerializeField] private float LineOffset = -9;
        [SerializeField] private float AtGCamZoom = 0.005f;
        [Header("///////////////////////////////////////////////////////////")]
        [SerializeField] private Rigidbody VehicleRigidbody;
        [SerializeField] private Rigidbody BombRigidbody;
        [SerializeField] private float RefreshRateOfPrediction = 0.1f;
        [SerializeField] private float SecondsBetweenRaycast = 1;
        [SerializeField] private float BombLifeTime = 8;

        private float StepsPerSecond;
        private bool hitdetect = false;
        private Vector3 groundzero;
        private float dt;
        private int StepsToPredict;
        private Vector3 Gravity;
        private float a;
        private float Drag;
        private int TrajectoryResolution;

        private Transform HUDControlTransform;
        private float DistanceFromHead = 1.333f;

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        [UdonSynced, FieldChangeCallback(nameof(BombFire))] private ushort _BombFire;
        public ushort BombFire
        {
            set
            {
                if (value > _BombFire)//if _BombFire is higher locally, it's because a late joiner just took ownership or value was reset, so don't launch
                { LaunchBomb(); }
                _BombFire = value;
            }
            get => _BombFire;
        }
        private float boolToggleTime;
        private bool AnimOn = false;
        [System.NonSerializedAttribute] public SaccEntity EntityControl;
        private bool UseLeftTrigger = false;
        private float Trigger;
        private bool TriggerLastFrame;
        private int BombPoint = 0;
        private float LastBombDropTime = -999f;
        [System.NonSerializedAttribute] public int FullBombs;
        private float FullBombsDivider;
        private Transform VehicleTransform;
        private float reloadspeed;
        private bool LeftDial = false;
        private bool Piloting = false;
        private bool OthersEnabled = false;
        private bool func_active = false;
        private int DialPosition = -999;
        private int NumChildrenStart;
        private VRCPlayerApi localPlayer;
        [System.NonSerializedAttribute] public Transform CenterOfMass;
        [System.NonSerializedAttribute] public bool IsOwner;
        public void DFUNC_LeftDial() { UseLeftTrigger = true; }
        public void DFUNC_RightDial() { UseLeftTrigger = false; }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void SFEXT_L_EntityStart()
        {
            FullBombs = NumBomb;
            if (BombHoldDelay < BombDelay) { BombHoldDelay = BombDelay; }
            FullBombsDivider = 1f / (NumBomb > 0 ? NumBomb : 10000000);
            reloadspeed = FullBombs / FullReloadTimeSec;
            EntityControl = (SaccEntity)SAVControl.GetProgramVariable("EntityControl");
            BombAnimator = EntityControl.GetComponent<Animator>();
            CenterOfMass = EntityControl.CenterOfMass;
            VehicleTransform = EntityControl.transform;
            localPlayer = Networking.LocalPlayer;
            IsOwner = (bool)SAVControl.GetProgramVariable("IsOwner");

            FindSelf();

            UpdateAmmoVisuals();

            NumChildrenStart = transform.childCount;
            if (Bomb)
            {
                int NumToInstantiate = Mathf.Min(FullBombs, 30);
                for (int i = 0; i < NumToInstantiate; i++)
                {
                    InstantiateWeapon();
                }
            }

            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            if (!DoCCIP) return;

            Gravity = Physics.gravity;
            dt = Time.fixedDeltaTime;
            StepsPerSecond = 1 / dt;
            Drag = BombRigidbody.drag;
            a = 1 - (Drag * dt);
            StepsToPredict = (int)(StepsPerSecond * SecondsBetweenRaycast);
            TrajectoryResolution = (int)(BombLifeTime / SecondsBetweenRaycast);

            if (LinkedHUDControl)
            {
                HUDControlTransform = LinkedHUDControl.transform;
                DistanceFromHead = LinkedHUDControl.distance_from_head;
            }
            else { Debug.LogError("HUD control not linked to [DFUNC_Bomb]"); HUDControlTransform = transform; }
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private GameObject InstantiateWeapon()
        {
            GameObject NewWeap = VRCInstantiate(Bomb);
            NewWeap.transform.SetParent(transform);
            return NewWeap;
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void SFEXT_O_PilotEnter()
        {
            Piloting = true;
            if (HUDText_Bomb_ammo) { HUDText_Bomb_ammo.text = NumBomb.ToString("F0"); }
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void SFEXT_G_PilotExit()
        {
            if (OthersEnabled) { DisableForOthers(); }
            if (DoAnimBool && !AnimBoolStayTrueOnExit && AnimOn)
            { SetBoolOff(); }
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void SFEXT_O_PilotExit()
        {
            func_active = false;
            Piloting = false;
            gameObject.SetActive(false);
            if (AtGScreen) { AtGScreen.SetActive(false); }
            if (AtGCam) { AtGCam.gameObject.SetActive(false); }
            if (AtGCam) AtGCam.transform.rotation = Quaternion.identity;
            if (HudCCIP) { HudCCIP.gameObject.SetActive(false); }
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void SFEXT_P_PassengerEnter()
        {
            if (HUDText_Bomb_ammo) { HUDText_Bomb_ammo.text = NumBomb.ToString("F0"); }
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void DFUNC_Selected()
        {
            TriggerLastFrame = true;
            func_active = true;
            gameObject.SetActive(true);
            if (DoAnimBool && !AnimOn)
            { SendCustomNetworkEvent(VRC.Udon.Common.Interfaces.NetworkEventTarget.All, nameof(SetBoolOn)); }
            if (!OthersEnabled) { SendCustomNetworkEvent(VRC.Udon.Common.Interfaces.NetworkEventTarget.All, nameof(EnableForOthers)); }
            if (AtGScreen) AtGScreen.SetActive(true);
            if (AtGCam) { AtGCam.gameObject.SetActive(true); }
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void DFUNC_Deselected()
        {
            func_active = false;
            gameObject.SetActive(false);
            if (DoAnimBool && AnimOn)
            { SendCustomNetworkEvent(VRC.Udon.Common.Interfaces.NetworkEventTarget.All, nameof(SetBoolOff)); }
            if (OthersEnabled) { SendCustomNetworkEvent(VRC.Udon.Common.Interfaces.NetworkEventTarget.All, nameof(DisableForOthers)); }
            if (AtGScreen) { AtGScreen.SetActive(false); }
            if (AtGCam) { AtGCam.gameObject.SetActive(false); }

            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            if (!DoCCIP) return;

            if (HudCCIP) { HudCCIP.gameObject.SetActive(false); }
            if (AtGCam) AtGCam.transform.rotation = Quaternion.identity;
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void SFEXT_G_Explode()
        {
            BombPoint = 0;
            NumBomb = FullBombs;
            UpdateAmmoVisuals();
            if (DoAnimBool && AnimOn)
            { SetBoolOff(); }
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void SFEXT_G_RespawnButton()
        {
            NumBomb = FullBombs;
            UpdateAmmoVisuals();
            BombPoint = 0;
            if (DoAnimBool && AnimOn)
            { SetBoolOff(); }
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void SFEXT_G_ReSupply()
        {
            if (NumBomb != FullBombs)
            { SAVControl.SetProgramVariable("ReSupplied", (int)SAVControl.GetProgramVariable("ReSupplied") + 1); }
            NumBomb = (int)Mathf.Min(NumBomb + Mathf.Max(Mathf.Floor(reloadspeed), 1), FullBombs);
            BombPoint = 0;
            UpdateAmmoVisuals();
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void SFEXT_O_TakeOwnership() { IsOwner = true; }
        public void SFEXT_O_LoseOwnership() { IsOwner = false; }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void UpdateAmmoVisuals()
        {
            BombAnimator.SetFloat(AnimFloatName, (float)NumBomb * FullBombsDivider);
            if (HUDText_Bomb_ammo) { HUDText_Bomb_ammo.text = NumBomb.ToString("F0"); }
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void EnableForOthers()
        {
            if (!Piloting)
            { gameObject.SetActive(true); BombFire = 0; }
            OthersEnabled = true;
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void DisableForOthers()
        {
            if (!Piloting)
            { gameObject.SetActive(false); }
            OthersEnabled = false;
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void Update()
        {
            if (!func_active) return;

            float Trigger;
            if (UseLeftTrigger)
            { Trigger = Input.GetAxisRaw("Oculus_CrossPlatform_PrimaryIndexTrigger"); }
            else
            { Trigger = Input.GetAxisRaw("Oculus_CrossPlatform_SecondaryIndexTrigger"); }
            if (Trigger > 0.75 || (Input.GetKey(KeyCode.Space)))
            {
                if (!TriggerLastFrame)
                {
                    if (NumBomb > 0 && (AllowFiringWhenGrounded || !(bool)SAVControl.GetProgramVariable("Taxiing")) && ((Time.time - LastBombDropTime) > BombDelay))
                    {
                        BombFireFunc();
                    }
                }
                else if (NumBomb > 0 && ((Time.time - LastBombDropTime) > BombHoldDelay) && (AllowFiringWhenGrounded || !(bool)SAVControl.GetProgramVariable("Taxiing")))
                {///launch every BombHoldDelay
                    BombFireFunc();
                }
                TriggerLastFrame = true;
            }
            else { TriggerLastFrame = false; }
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void BombFireFunc()
        {
            BombFire++;
            RequestSerialization();
            if (IsOwner)
            { EntityControl.SendEventToExtensions("SFEXT_O_BombLaunch"); }
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private float PredictionTimer = 0;
        private void LateUpdate()
        {
            if (!DoCCIP || !func_active) return;

            PredictionTimer += dt;
            if (PredictionTimer > RefreshRateOfPrediction)
            {
                PredictionTimer = 0;
                WolframTrajectoryPrediction(transform.position, VehicleRigidbody.velocity, Drag);
            }

            CCIPHUD();
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void WolframTrajectoryPrediction(Vector3 _startPos, Vector3 _startVelocity, float _drag)
        {
            Vector3 Constants = ConstantsCalculation(_startVelocity);
            Vector3 NextVelocity = PredictedVelocity(Constants);
            Vector3 NextPos = PredictedPos(Constants, _startPos);

            hitdetect = false;
            for (int i = 1; i < TrajectoryResolution; i++)
            {
                Constants = ConstantsCalculation(NextVelocity);
                NextVelocity = PredictedVelocity(Constants);
                Vector3 LastPredictedPos = NextPos;
                NextPos = PredictedPos(Constants, LastPredictedPos);

                if (!hitdetect)
                {
                    Vector3 RayDir = NextPos - LastPredictedPos;

                    Ray ray = new Ray(origin: LastPredictedPos, direction: RayDir.normalized);
                    RaycastHit hit;
                    if (Physics.Raycast(ray, out hit, RayDir.magnitude + 2))
                    {
                        hitdetect = true;
                        groundzero = hit.point;
                    }
                }
            }
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private Vector3 CCIPLookDir;
        private void CCIPHUD()
        {
            CCIPLookDir = Vector3.Slerp(CCIPLookDir, groundzero - HUDControlTransform.position, CCIPSmoothing);
            float DirAngleCorr = Vector3.SignedAngle(Vector3.ProjectOnPlane(CCIPLookDir, Vector3.up), Vector3.ProjectOnPlane(LinkedHudVelocityVector.forward, Vector3.up), Vector3.up);
            CCIPLookDir = Quaternion.AngleAxis(DirAngleCorr, Vector3.up) * CCIPLookDir;

            Quaternion LookAtPlaneUp = Quaternion.LookRotation(-CCIPLookDir, Vector3.up);

            HudCCIP.gameObject.SetActive(hitdetect);
            HudCCIP.position = HUDControlTransform.position + CCIPLookDir.normalized;
            HudCCIP.localPosition = HudCCIP.localPosition.normalized * DistanceFromHead;
            HudCCIP.transform.rotation = LookAtPlaneUp;

            TopOfCCIPLine.transform.position = LinkedHudVelocityVector.position + (Vector3.ProjectOnPlane(Vector3.up, LinkedHudVelocityVector.forward) * LineOffset);
            TopOfCCIPLine.transform.rotation = LookAtPlaneUp;

            if (AtGCam)
            {
                AtGCam.transform.rotation = Quaternion.LookRotation(CCIPLookDir, Vector3.up);
                AtGCam.fieldOfView = Mathf.Clamp(CCIPLookDir.magnitude * AtGCamZoom, 1, 60);
            }
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private Vector3 PredictedVelocity(Vector3 Constants)
        {
            float x = (Mathf.Pow(a, StepsToPredict - 1) * (Constants.x * Drag - Gravity.x * a) + Gravity.x) / Drag;
            float y = (Mathf.Pow(a, StepsToPredict - 1) * (Constants.y * Drag - Gravity.y * a) + Gravity.y) / Drag;
            float z = (Mathf.Pow(a, StepsToPredict - 1) * (Constants.z * Drag - Gravity.z * a) + Gravity.z) / Drag;

            return new Vector3(x, y, z);
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private Vector3 ConstantsCalculation(Vector3 _vel)
        {
            float x = ((_vel.x * Drag - Gravity.x) * a + Gravity.x * a) / Drag;
            float y = ((_vel.y * Drag - Gravity.y) * a + Gravity.y * a) / Drag;
            float z = ((_vel.z * Drag - Gravity.z) * a + Gravity.z * a) / Drag;

            return new Vector3(x, y, z);
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private Vector3 PredictedPos(Vector3 Constants, Vector3 _startPos)
        {
            float x = dt * (Mathf.Pow(a, StepsToPredict) * (Constants.x * Drag - a * Gravity.x) + Gravity.x * ((a - 1) * StepsToPredict + a) - Constants.x * Drag) / ((a - 1) * Drag) + _startPos.x;
            float y = dt * (Mathf.Pow(a, StepsToPredict) * (Constants.y * Drag - a * Gravity.y) + Gravity.y * ((a - 1) * StepsToPredict + a) - Constants.y * Drag) / ((a - 1) * Drag) + _startPos.y;
            float z = dt * (Mathf.Pow(a, StepsToPredict) * (Constants.z * Drag - a * Gravity.z) + Gravity.z * ((a - 1) * StepsToPredict + a) - Constants.z * Drag) / ((a - 1) * Drag) + _startPos.z;

            return new Vector3(x, y, z);
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void LaunchBomb()
        {
            LastBombDropTime = Time.time;
            if (NumBomb > 0) { NumBomb--; }
            BombAnimator.SetTrigger(AnimFiredTriggerName);
            if (Bomb)
            {
                GameObject NewBomb;
                if (transform.childCount - NumChildrenStart > 0)
                { NewBomb = transform.GetChild(NumChildrenStart).gameObject; }
                else
                { NewBomb = InstantiateWeapon(); }
                if (WorldParent) { NewBomb.transform.SetParent(WorldParent); }
                else { NewBomb.transform.SetParent(null); }
                NewBomb.transform.SetPositionAndRotation(BombLaunchPoints[BombPoint].position, BombLaunchPoints[BombPoint].rotation);
                NewBomb.SetActive(true);
                NewBomb.GetComponent<Rigidbody>().velocity = (Vector3)SAVControl.GetProgramVariable("CurrentVel");
                BombPoint++;
                if (BombPoint == BombLaunchPoints.Length) BombPoint = 0;
            }
            UpdateAmmoVisuals();
        }
        private void FindSelf()
        {
            int x = 0;
            foreach (UdonSharpBehaviour usb in EntityControl.Dial_Functions_R)
            {
                if (this == usb)
                {
                    DialPosition = x;
                    return;
                }
                x++;
            }
            LeftDial = true;
            x = 0;
            foreach (UdonSharpBehaviour usb in EntityControl.Dial_Functions_L)
            {
                if (this == usb)
                {
                    DialPosition = x;
                    return;
                }
                x++;
            }
            DialPosition = -999;
            Debug.LogWarning("DFUNC_Bomb: Can't find self in dial functions");
        }
        public void SetBoolOn()
        {
            boolToggleTime = Time.time;
            AnimOn = true;
            BombAnimator.SetBool(AnimBoolName, AnimOn);
        }
        public void SetBoolOff()
        {
            boolToggleTime = Time.time;
            AnimOn = false;
            BombAnimator.SetBool(AnimBoolName, AnimOn);
        }
        public void KeyboardInput()
        {
            if (LeftDial)
            {
                if (EntityControl.LStickSelection == DialPosition)
                { EntityControl.LStickSelection = -1; }
                else
                { EntityControl.LStickSelection = DialPosition; }
            }
            else
            {
                if (EntityControl.RStickSelection == DialPosition)
                { EntityControl.RStickSelection = -1; }
                else
                { EntityControl.RStickSelection = DialPosition; }
            }
        }
    }
}